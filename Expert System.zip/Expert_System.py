import os
import json
from typing import List, Dict, Tuple
from flask import Flask, render_template, request, jsonify

# --- LLM Setup ---
client = None
GEMINI_MODEL = "gemini-2.5-flash"
GEMINI_API_KEY = os.environ.get("GEMINI_API_KEY")

if GEMINI_API_KEY:
    try:
        from google import genai
        from google.genai.errors import APIError
        
        # Initialize the Gemini Client using the environment variable
        client = genai.Client(api_key=GEMINI_API_KEY)
        print("Gemini Client initialized successfully.")
    except ImportError:
        print("Warning: Google GenAI SDK not installed. LLM functionality will be disabled.")
    except Exception as e:
        print(f"Error initializing Gemini client: {e}. LLM functionality disabled.")
else:
    print("Warning: GEMINI_API_KEY environment variable not found. LLM functionality will be disabled.")


# --- EXPERT SYSTEM CORE LOGIC ---

KB = {}
KB_PATH = "ES_KB.json"

# Utility: Certainty Factor math
def combine_cf(cf1: float, cf2: float) -> float:
    # ... (combine_cf function remains the same)
    cf1 = max(-1.0, min(1.0, cf1))
    cf2 = max(-1.0, min(1.0, cf2))

    if cf1 >= 0 and cf2 >= 0:
        return cf1 + cf2 * (1 - cf1)
    if cf1 <= 0 and cf2 <= 0:
        return cf1 + cf2 * (1 + cf1)

    denom = 1 - min(abs(cf1), abs(cf2))
    if denom == 0:
        return (cf1 + cf2) / 2
    return (cf1 + cf2) / denom


def load_kb(path: str) -> Dict:
    """Loads the Knowledge Base from the specified JSON path."""
    global KB
    try:
        with open(path, "r") as f:
            KB = json.load(f)
            print(f"Knowledge Base loaded successfully from {path}.")
            return KB
    except FileNotFoundError:
        print(f"Error: Knowledge Base file not found at {path}. RBM will not function.")
        return {}
    except json.JSONDecodeError:
        print(f"Error: Knowledge Base file at {path} is not valid JSON. RBM will not function.")
        return {}


# Load KB on startup
KB = load_kb(KB_PATH)


# Inference (Rule Matching)
def match_rule(rule_if: List[str], facts: List[str]) -> bool:
    facts_set = set([f.lower() for f in facts])
    needed = set([c.lower() for c in rule_if])
    return needed.issubset(facts_set)


def forward_inference(kb: Dict, facts: List[str]) -> Dict[str, float]:
    results = {}
    for rule in kb.get("rules", []):
        conds = rule.get("if", [])
        disease = rule.get("then")
        try:
             cf = float(rule.get("certainty", 0.0))
        except ValueError:
             cf = 0.0

        if match_rule(conds, facts):
            if disease not in results:
                results[disease] = cf
            else:
                results[disease] = combine_cf(results[disease], cf)

    return results


# Treatment look-up
def find_treatment(kb: Dict, disease: str) -> Dict:
    for t in KB.get("treatments", []):
        if t["disease"].lower() == disease.lower():
            return t
    return None


def get_rbm_results(user_facts: List[str]) -> Tuple[Dict[str, float], List[str]]:
    """Runs the rule-based model and identifies unmatched symptoms."""
    
    # 1. Get all known symptoms from the RBM rules
    all_kb_symptoms = set()
    for rule in KB.get("rules", []):
        for symptom in rule.get("if", []):
            all_kb_symptoms.add(symptom.strip().lower())
    
    # Also include symptoms listed in the main 'symptoms' section just for completeness
    for symptom_obj in KB.get("symptoms", []):
        all_kb_symptoms.add(symptom_obj['name'].lower())


    # 2. Run inference
    diagnoses = forward_inference(KB, user_facts)
    
    # 3. Identify symptoms not in the KB
    unmatched_symptoms = []
    for fact in user_facts:
        if fact not in all_kb_symptoms:
            unmatched_symptoms.append(fact)

    return diagnoses, unmatched_symptoms


def get_llm_advice(unmatched_symptoms: List[str], rbm_results: Dict[str, float], all_symptoms: List[str]) -> str:
    """Generates advice from the LLM based on unmatched symptoms and RBM results."""
    if not client:
        return "LLM service is unavailable because the GEMINI_API_KEY was not set or the SDK failed to initialize."
    
    # ... (LLM prompt generation remains the same)
    symptoms_str = ", ".join(all_symptoms)
    unmatched_str = ", ".join(unmatched_symptoms)
    rbm_str = "\n".join([f"- {d} (CF: {c:.2f})" for d, c in rbm_results.items()])
    
    prompt = (
        "You are an AI medical assistant for a blood infection expert system. "
        "The user provided the following symptoms: "
        f"**ALL SYMPTOMS:** {symptoms_str}. "
        "The system's Rule-Based Model (RBM) found these initial diagnoses: "
        f"**RBM Diagnoses:**\n{rbm_str if rbm_str else 'None'}. "
        "The following symptoms were not recognized by the RBM: "
        f"**Unmatched Symptoms:** {unmatched_str if unmatched_str else 'None'}. "
        "\n\n"
        "Based on ALL symptoms and the RBM's output, provide a concise and cautious advisory (3-4 sentences) about the combination of findings. "
        "If there are any high-confidence RBM results (CF > 0.8), mention the need for follow-up. "
        "If there are unmatched symptoms, suggest seeking professional medical review. "
        "Stress that you are an AI and not a substitute for a real doctor. Do NOT suggest a specific medicine. "
        "Provide your expert advice (Max 4 sentences):"
    )

    try:
        response = client.models.generate_content(
            model=GEMINI_MODEL,
            contents=prompt,
        )
        return response.text
    except APIError as e:
        print(f"Gemini API Error: {e}")
        return f"Error communicating with LLM: Gemini API Error."
    except Exception as e:
        print(f"General LLM Error: {e}")
        return f"An unexpected error occurred with the LLM."


# --- FLASK WEB APPLICATION ---

app = Flask(__name__)

@app.route("/")
def index():
    """Renders the main web page."""
    return render_template("diagonose.html")

@app.route("/diagnose", methods=["POST"])
def diagnose():
    """Handles the diagnosis request."""
    user_input = request.form.get("symptoms", "").strip()
    if not user_input:
        return jsonify({
            "status": "error",
            "message": "Please enter at least one symptom."
        })

    user_facts = [s.strip().lower() for s in user_input.split(",")]

    # 1. Run Rule-Based Model (RBM)
    rbm_diagnoses, unmatched_symptoms = get_rbm_results(user_facts)

    final_results = []
    for disease, cf in rbm_diagnoses.items():
        treatment = find_treatment(KB, disease)
        final_results.append({
            "disease": disease,
            "confidence": f"{cf:.2f}",
            "treatment": treatment if treatment else "No specific treatment found in KB."
        })

    final_results.sort(key=lambda x: float(x['confidence']), reverse=True)


    # 2. Get LLM Advice
    llm_advice = get_llm_advice(unmatched_symptoms, rbm_diagnoses, user_facts)
    
    # 3. Combine and output
    num_rules = len(KB.get('rules', []))
    num_treatments = len(KB.get('treatments', []))

    return jsonify({
        "status": "success",
        "input_symptoms": user_input,
        "rbm_diagnoses": final_results,
        "unmatched_symptoms": unmatched_symptoms,
        "llm_advice": llm_advice,
        "kb_status": f"Knowledge Base loaded with {num_rules} rules and {num_treatments} treatments."
    })

if __name__ == "__main__":
    app.run(debug=True)
   